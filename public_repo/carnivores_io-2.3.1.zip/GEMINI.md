# CarnivoresIO

**CarnivoresIO** is a high-performance Blender extension (compatible with Blender 4.2+) for importing and exporting legacy 3D model formats from the *Carnivores* game engine series. It provides a professional-grade toolset for handling `.3df` (static), `.car` (animated), and `.3dn` (mobile/HD) formats.

## Project Overview

- **Primary Purpose:** Bridge the gap between modern 3D workflows in Blender and the legacy binary formats of the Carnivores game engine.
- **Main Technologies:**
    - **Blender API (bpy):** Integration with Blender's UI, viewport, and data structures.
    - **NumPy:** Used extensively for high-performance binary parsing, data validation, and geometry processing.
    - **Aud (Blender Audio Engine):** Powers the real-time NLA-synchronized sound playback system.
- **Architecture:**
    - `core/`: Constants, binary data types (dtypes), and shared core logic.
    - `parsers/`: Modular parsers and exporters for each format. Includes `validate.py` for rigorous data integrity checks.
    - `operators/`: Blender operators for import/export, animation management, and face flag tools.
    - `utils/`: Helper modules for animation baking, audio handling, logging, and common geometry operations.
    - `doc/`: Technical specifications for formats and internal implementation details (e.g., Skeleton Reconstruction).

## Key Features

- **Static & Animated Support:** Robust handling of `.3df` and `.car` files, including vertex animation and skeleton reconstruction.
- **Skeleton Reconstruction:** A custom MST-based algorithm that infers a bone hierarchy from vertex group "owners" in `.car` files.
- **NLA Sound System:** Links `.wav` files to NLA strips for synchronized playback during animation scrubbing.
- **Face Flag Tools:** Viewport visualization and bitmask-based selection for engine-specific face properties (Transparency, Double-Sided, etc.).
- **Rigorous Validation:** Built-in checks for vertex/face counts, UV ranges, bone cycles, and engine-specific limits (e.g., 1024/2048 element caps).

## Building and Running

### Development Setup
1. **Installation:** This project uses the Blender 4.2+ Extension system. To develop locally:
    - Link this directory to your Blender user extensions folder.
    - Alternatively, zip the contents (respecting `blender_manifest.toml` exclusions) and install via `Preferences > Get Extensions > Install from Disk`.
2. **Execution:** Once enabled, the tools are available under:
    - `File > Import > Carnivores Engine`
    - `File > Export > Carnivores Engine`
    - `Sidebar (N) > Carnivores` tab (Animation and Face Flag tools).

### Debugging
- **Debug Mode:** Enable "Debug Mode" in the Addon Preferences to see verbose NumPy-level logs and execution timings in the System Console.
- **System Console:** Always keep the System Console open (`Window > Toggle System Console` on Windows) during development to catch parser warnings and validation errors.

## Development Conventions

- **Binary Data:** Use `numpy.dtype` definitions in `core/core.py` for all binary structure mapping to ensure alignment with engine specs.
- **Validation:** All new parsing or export logic should utilize `parsers/validate.py` to maintain compatibility with legacy tools (like AltEdit).
- **Logging:** Use the custom logger in `utils/logger.py` (`debug`, `info`, `warn`, `error`) instead of standard `print()`.
- **UI Patterns:** Operators should be registered in `operators/__init__.py` and follow the `CARNIVORES_OT_*` naming convention.
- **Performance:** Avoid iterating over large vertex/face arrays with Python loops; prefer NumPy vectorization for performance-critical geometry tasks.
