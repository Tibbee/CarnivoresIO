# AGENTS.md

Blender 4.2+ extension (add-on) for importing/exporting Carnivores engine formats (`.3df`, `.car`, `.3dn`).

## Building

```powershell
.\tools\build_repo.ps1
```

This runs Blender's `extension build` and `extension server-generate` commands, placing the `.zip` in `public_repo/` and regenerating `index.json`. Prerequisites: Blender must be at `D:\Portable\Blender\blender.exe` relative to the repo, or on PATH.

Releases are triggered by pushing a `v*` tag (GitHub Actions: `.github/workflows/release.yml`).

## Architecture

- `__init__.py` — Addon registration, custom properties, preferences (debug mode toggle), Blender handlers (NLA sound, preset deployment)
- `core/core.py` — `numpy.dtype` definitions for every binary structure (header, face, vertex, bone). All format I/O references these.
- `core/constants.py` — Face flag bit definitions (`FACE_FLAG_OPTIONS`) and `TEXTURE_WIDTH = 256`
- `parsers/` — One file per format per direction (e.g., `parse_3df.py`, `export_car.py`). Each parser validates through `parsers/validate.py`.
- `operators/` — Blender operators (`CARNIVORES_OT_*`) and panels (`VIEW3D_PT_*`). All classes are listed in `operators/__init__.py`.
- `utils/` — Shared utilities: mesh creation, bone collection, texture conversion, animation helpers, flags, logger
- `doc/` — Deep-dive docs: format specifications, skeleton reconstruction algorithm, NLA sound system, Blender 5.0 migration notes

## Conventions

- **Logging:** Use `from ..utils.logger import debug, info, warn, error`. Never use `print()`.
- **Performance:** Use NumPy vectorization for vertex/face/flag operations. The `@timed` decorator (`utils/common.py`) logs execution times.
- **Face flags:** Stored as a face-domain `INT` attribute named `3df_flags` on the mesh. Use `utils/flags.py` helpers.
- **Operator naming:** `CARNIVORES_OT_*` for operators, `VIEW3D_PT_*` for panels. Register in `operators/__init__.py`.
- **Binary types:** All format structs live as `numpy.dtype` in `core/core.py`. Never hardcode offsets or sizes.
- **Validation:** Gather warnings in `ParserContext.warnings` (list of strings) during parse/export. Raise `ValueError` for fatal issues.

## Critical Gotchas

- **Blender 5.0 API break:** `action.fcurves` was removed. F-Curves now live under `action.slots[i].channelbags[j].fcurves`. See `doc/development/blender_5_0_migration.md` and the `get_action_channelbag` helper in `utils/animation.py`.
- **Coordinate handedness:** Carnivores is left-handed, Blender is right-handed. Import flips vertex winding and UVs. Export reverses this. The "Flip Handedness" toggle controls this.
- **Texture width is always 256** (ARGB1555). Export enforces this. Texture size in bytes = 256 × 2 × height, so it must be a multiple of 512.
- **Engine limits:** 1024 vertices/faces (AltEdit compatibility warning), 2048 (hard error). `validate.py` checks these.
- **Preset deployment:** On registration, `utils/preset_deployment.py` copies preset `.py` files from `presets/operator/` into Blender's user scripts directory (skips if already present).

## Testing

There is no automated test suite. Testing is manual inside Blender:
- Enable "Debug Mode" in addon preferences to see verbose logs and `@timed` output
- Open the System Console (`Window > Toggle System Console` on Windows) to see parser warnings and validation errors
- Test with `.3df`/`.car` files covering edge cases (empty textures, cyclic bone hierarchies, high vertex counts)
