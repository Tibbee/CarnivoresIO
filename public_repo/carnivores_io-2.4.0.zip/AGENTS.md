# AGENTS.md

Blender 4.2+ extension (add-on) for importing/exporting Carnivores engine formats (`.3df`, `.car`, `.3dn`).

## Building

```powershell
.\tools\build_repo.ps1
```

This runs Blender's `extension build` and `extension server-generate` commands, placing the `.zip` in `public_repo/` and regenerating `index.json`. Prerequisites: Blender must be at `D:\Portable\Blender\blender.exe` relative to the repo, or on PATH.

Releases are triggered by pushing a `v*` tag (GitHub Actions: `.github/workflows/release.yml`).

## Architecture

> Full architecture overview and developer guide: [`doc/DEVELOPMENT.md`](doc/DEVELOPMENT.md#developer-notes).

- `__init__.py` — Addon registration, custom properties, preferences (debug mode toggle), Blender handlers (NLA sound, preset deployment)
- `core/core.py` — `numpy.dtype` definitions for every binary structure (header, face, vertex, bone). All format I/O references these.
- `core/constants.py` — Face flag bit definitions (`FACE_FLAG_OPTIONS`) and `TEXTURE_WIDTH = 256`
- `parsers/` — One file per format per direction (e.g., `parse_3df.py`, `export_car.py`). Each parser validates through `parsers/validate.py`.
- `operators/` — Blender operators (`CARNIVORES_OT_*`) and panels (`VIEW3D_PT_*`). All classes are listed in `operators/__init__.py`.
- `utils/` — Shared utilities: mesh creation, bone collection, texture conversion, animation helpers, flags, logger
- `doc/` — Format specs ([`FORMATS.md`](doc/FORMATS.md)), core algorithms ([`SYSTEMS.md`](doc/SYSTEMS.md)), developer guide ([`DEVELOPMENT.md`](doc/DEVELOPMENT.md)), constants/limits ([`reference.md`](doc/reference.md))

## Conventions

- **Logging:** Use `from ..utils.logger import debug, info, warn, error`. Never use `print()`.
- **Performance:** Use NumPy vectorization for vertex/face/flag operations. The `@timed` decorator (`utils/common.py`) logs execution times.
- **Face flags:** Stored as a face-domain `INT` attribute named `3df_flags` on the mesh. Use `utils/flags.py` helpers.
- **Operator naming:** `CARNIVORES_OT_*` for operators, `VIEW3D_PT_*` for panels. Register in `operators/__init__.py`.
- **Binary types:** All format structs live as `numpy.dtype` in `core/core.py`. Never hardcode offsets or sizes.
- **Validation:** Gather warnings in `ParserContext.warnings` (list of strings) during parse/export. Raise `ValueError` for fatal issues.

## Critical Gotchas

- **Blender 5.0 API break:** `action.fcurves` was removed. F-Curves now live under `action.slots[i].channelbags[j].fcurves`. See `doc/development.md#blender-50-migration-guide` and the `get_action_channelbag` helper in `utils/animation.py`.
- **Coordinate conversion:** Distinguish binary model space from engine runtime space. Carnivores files use `+Y` up and `+Z` model-forward; C2 reflects file Z at runtime. With default add-on settings, file `(x, y, z)` maps to Blender `(x, z, y)`. This transform changes orientation, so import/export reverse triangle and UV corner order when the legacy-named "Flip Handedness" toggle is enabled. See `doc/FORMATS.md#coordinate--axis-conversion`.
- **Texture width is always 256** (ARGB1555). Export enforces this. Texture size in bytes = 256 × 2 × height, so it must be a multiple of 512.
- **Compatibility limits:** 1024 vertices/faces is a legacy AltEdit warning, not a current-engine hard limit. Structural validation has no fixed mesh-count ceiling; current C2 MEE compatibility also reports its 1024 standalone-object and 64 animation/sound array limits. See `parsers/validate.py` and `doc/reference.md`.
- **Preset deployment:** On registration, `utils/preset_deployment.py` copies preset `.py` files from `presets/operator/` into Blender's user scripts directory (skips if already present).

## Testing

Automated suite (118 tests, 11 files under `tests/`): owner mapping, structural/CAR validation, rig geometry/hierarchy/adapter/reconciliation, rig lifecycle policies, performance fast paths, audio playback selection, addon preferences, and import/export robustness fixes. Runs with Blender's bundled Python — see [`tests/README.md`](tests/README.md). No fixture files are committed; synthetic fixtures are generated in test code.

Manual testing in Blender:
- Enable "Debug Mode" in addon preferences to see verbose logs and `@timed` output
- Open the System Console (`Window > Toggle System Console` on Windows) to see parser warnings and validation errors
- Test with `.3df`/`.car` files covering edge cases (empty textures, cyclic bone hierarchies, high vertex counts)
- Rig regression checklist: [`doc/RIG_TEST_CHECKLIST.md`](doc/RIG_TEST_CHECKLIST.md)
- Audio regression checklist: [`doc/AUDIO_TEST_CHECKLIST.md`](doc/AUDIO_TEST_CHECKLIST.md)
